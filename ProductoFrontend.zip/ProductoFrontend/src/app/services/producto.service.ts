import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable, Subject } from 'rxjs';
import { Producto } from '../models/producto';
import { HttpClient } from '@angular/common/http';
import { getProductosMenorStockYTotalDTO } from '../models/getProductosMenorStockYTotalDTO';
import { cantidadMarcasRepetidasDTO } from '../models/cantidadMarcasRepetidasDTO';
const base_url = environment.base;

@Injectable({
  providedIn: 'root'
})
export class ProductoService {
  private url = `${base_url}/productos`;
  private listaCambio = new Subject<Producto[]>();
  constructor(private http:HttpClient) { }

  list() {
    return this.http.get<Producto[]>(this.url);
  }
  insert(p: Producto) {
    return this.http.post(this.url, p);
  }
  setList(listaNueva: Producto[]) {
    this.listaCambio.next(listaNueva);
  }
  getList() {
    return this.listaCambio.asObservable();
  }
  listId(id: number) {
    return this.http.get<Producto>(`${this.url}/${id}`);
  }
  update(p: Producto) {
    return this.http.put(this.url, p);
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }
  getStock(): Observable<getProductosMenorStockYTotalDTO[]> {
    return this.http.get<getProductosMenorStockYTotalDTO[]>(
      `${this.url}/getProductosMenorStockYTotal`);
  }
  getCantidad(): Observable<cantidadMarcasRepetidasDTO[]>{
    return this.http.get<cantidadMarcasRepetidasDTO[]>(
      `${this.url}/cantidadMarcasRepetidas`);
  }
}
