import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { TipoProducto } from '../models/tipoproducto';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
const base_url = environment.base;

@Injectable({
  providedIn: 'root'
})
export class TipoproductoService {
  private url = `${base_url}/tiposproductos`;
  private listaCambio = new Subject<TipoProducto[]>();
  constructor(private http:HttpClient) {}

  list() {
    return this.http.get<TipoProducto[]>(this.url);
  }
  insert(t: TipoProducto) {
    return this.http.post(this.url, t);
  }
  setList(listaNueva: TipoProducto[]){
    this.listaCambio.next(listaNueva);
  }
  getList() {
    return this.listaCambio.asObservable();
  }
  listId(id: number) {
    return this.http.get<TipoProducto>(`${this.url}/${id}`);
  }
  update(t: TipoProducto) {
    return this.http.put(this.url, t); 
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }
}
