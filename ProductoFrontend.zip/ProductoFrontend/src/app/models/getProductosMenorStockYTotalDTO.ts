export class getProductosMenorStockYTotalDTO {
    idProducto: number = 0;
    nombreProducto: string = '';
    marcaProducto: string = '';
    precio: number = 0;
    stock: number = 0;
    monto: number = 0;
}