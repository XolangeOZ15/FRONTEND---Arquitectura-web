export class JwtRequest {
    username: string = "";
    password: string = "";
}