export class TipoProducto{
    idTipoProducto: number = 0;
    descripcionTipoProducto: string = '';
}