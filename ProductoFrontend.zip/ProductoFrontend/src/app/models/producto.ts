import { TipoProducto } from './tipoproducto';

export class Producto {
    idProducto: number = 0;
    nombreProducto: string = '';
    marcaProducto: string = '';
    precioProducto: number = 0;
    stockProducto: number = 0;
    tipoProducto: TipoProducto = new TipoProducto();
}