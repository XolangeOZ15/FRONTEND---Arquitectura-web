export class cantidadMarcasRepetidasDTO {
    marca: string = '';
    cantidadMarca: number = 0;
}