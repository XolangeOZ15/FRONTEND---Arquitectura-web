import { Routes } from '@angular/router';
import { ProductoComponent } from './components/producto/producto.component';
import { CreaeditaproductoComponent } from './components/producto/creaeditaproducto/creaeditaproducto.component';
import { TipoproductoComponent } from './components/tipoproducto/tipoproducto.component';
import { CreaeditatipoproductoComponent } from './components/tipoproducto/creaeditatipoproducto/creaeditatipoproducto.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { segGuard } from './guard/seguridad.guard';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'login', pathMatch: 'full'
    },
    {
        path: 'login', component: LoginComponent
    }, 
    {
        path: 'productos',
        component: ProductoComponent,
        children: [
            {
                path: 'nuevo',
                component: CreaeditaproductoComponent,
            },
            {
                path: 'ediciones/:id',
                component: CreaeditaproductoComponent,
            },
        ],
        canActivate:[segGuard]// solo construcciones, se debe agregar a cada uno  
    },
    {
        path: 'tiposproductos',
        component: TipoproductoComponent,
        children: [
            {
                path: 'nuevo',
                component: CreaeditatipoproductoComponent,
            },
            {
                path: 'ediciones/:id',
                component: CreaeditatipoproductoComponent,
            }
        ],
        canActivate:[segGuard]// solo construcciones, se debe agregar a cada uno   
    },
    {
        path: 'homes',
        component: HomeComponent,    
        canActivate:[segGuard]// solo construcciones, se debe agregar a cada uno
    }
];