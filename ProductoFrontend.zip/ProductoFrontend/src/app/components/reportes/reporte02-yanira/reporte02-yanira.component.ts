import { Component, OnInit } from '@angular/core';
import { ChartDataset, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { ProductoService } from '../../../services/producto.service';

@Component({
  selector: 'app-reporte02-yanira',
  standalone: true,
  imports: [BaseChartDirective],
  templateUrl: './reporte02-yanira.component.html',
  styleUrl: './reporte02-yanira.component.css'
})
export class Reporte02YaniraComponent implements OnInit{
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: string[] = [];
  //barChartType: ChartType = 'pie';
  barChartType: ChartType = 'doughnut';
  //barChartType: ChartType = 'line';
  //barChartType: ChartType = 'bar';
  //barChartType: ChartType = 'polarArea';

  barChartLegend = true;
  barChartData: ChartDataset[] = [];

  constructor(private pS: ProductoService) {}
  ngOnInit(): void {
    this.pS.getCantidad().subscribe((data) => {
      this.barChartLabels = data.map((item) => item.marca);
      this.barChartData = [
        {
          data: data.map((item) => item.cantidadMarca),
          label: 'Cantidad',
          backgroundColor: [
            '#4BACC6',
            '#9BBB59',
            '#8064A2',
            '#4F81BC',
            '#C0504D',
          ],
          borderColor: 'rgba(173, 216, 230, 1)',
          borderWidth: 1,
        },
      ];
    });
  }
}
