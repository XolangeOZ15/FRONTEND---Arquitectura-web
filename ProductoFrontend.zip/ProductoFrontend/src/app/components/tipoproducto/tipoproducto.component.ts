import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ListartipoproductoComponent } from './listartipoproducto/listartipoproducto.component';

@Component({
  selector: 'app-tipoproducto',
  standalone: true,
  imports: [RouterOutlet, ListartipoproductoComponent],
  templateUrl: './tipoproducto.component.html',
  styleUrl: './tipoproducto.component.css'
})
export class TipoproductoComponent implements OnInit{
  constructor(public route: ActivatedRoute){}
  ngOnInit(): void {}
}
