import { Component, OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule, NgIf } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { TipoProducto } from '../../../models/tipoproducto';
import { TipoproductoService } from '../../../services/tipoproducto.service';
import { ActivatedRoute, Params, Router, RouterLink } from '@angular/router';


@Component({
  selector: 'app-creaeditatipoproducto',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    NgIf,
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    RouterLink,
  ],
  templateUrl: './creaeditatipoproducto.component.html',
  styleUrl: './creaeditatipoproducto.component.css'
})
export class CreaeditatipoproductoComponent implements OnInit{
  form: FormGroup = new FormGroup({});
  tipoproducto: TipoProducto = new TipoProducto();
  edicion: boolean = false;
  id: number = 0;

  constructor(
    private tS: TipoproductoService,
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute
  ){}

  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data ['id'] != null;
      this.init();
    });

    this.form = this.formBuilder.group({
      codigo: [''],
      descripcion: ['', Validators.required],
    });
  }
  aceptar(): void {
    if (this.form.valid) {
      this.tipoproducto.idTipoProducto = this.form.value.codigo;
      this.tipoproducto.descripcionTipoProducto = this.form.value.descripcion;
      if(this.edicion) {
        this.tS.update(this.tipoproducto).subscribe(() =>{
          this.tS.list().subscribe((data) => {
            this.tS.setList(data);
          });
        });
      } else {
        this.tS.insert(this.tipoproducto).subscribe((data) => {
          this.tS.list().subscribe((data) => {
            this.tS.setList(data);
          });
        });
      }
        this.router.navigate(['tiposproductos']);
    }
  }

  init(){
    if (this.edicion) {
      this.tS.listId(this.id).subscribe((data) => {
        this.form = new FormGroup ({
          codigo: new FormControl(data.idTipoProducto),
          descripcion: new FormControl(data.descripcionTipoProducto),
        });
      });
    }
  }
}
