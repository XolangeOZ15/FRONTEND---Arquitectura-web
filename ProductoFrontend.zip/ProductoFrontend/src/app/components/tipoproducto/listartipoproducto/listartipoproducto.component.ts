import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { TipoProducto } from '../../../models/tipoproducto';
import { TipoproductoService } from '../../../services/tipoproducto.service';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginator } from '@angular/material/paginator';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-listartipoproducto',
  standalone: true,
  imports: [MatTableModule, RouterLink, MatButtonModule, MatPaginator, MatIconModule],
  templateUrl: './listartipoproducto.component.html',
  styleUrl: './listartipoproducto.component.css'
})
export class ListartipoproductoComponent implements OnInit {
  displayedColumns: string[] = [
    'codigo',
    'nombre',
    'accion01',
    'accion02',
  ];
  dataSource: MatTableDataSource<TipoProducto> = new MatTableDataSource();
  constructor(private tS:TipoproductoService) {}
  ngOnInit(): void {
    this.tS.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.tS.getList().subscribe((data)=>{
      this.dataSource=new MatTableDataSource(data);
    });
  }
  eliminar(id: number){
    this.tS.eliminar(id).subscribe((data) => {
      this.tS.list().subscribe((data) => {
        this.tS.setList(data);
      });
    });
  }
}
