import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ListarproductoComponent } from './listarproducto/listarproducto.component';

@Component({
  selector: 'app-producto',
  standalone: true,
  imports: [RouterOutlet, ListarproductoComponent],
  templateUrl: './producto.component.html',
  styleUrl: './producto.component.css'
})
export class ProductoComponent implements OnInit {
  constructor(public route: ActivatedRoute) {}
  ngOnInit(): void {}
}
