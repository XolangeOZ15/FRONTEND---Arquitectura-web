import { Component, OnInit} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Producto } from '../../../models/producto';
import { TipoproductoService } from '../../../services/tipoproducto.service';
import { Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule, NgIf } from '@angular/common';
import { ProductoService } from '../../../services/producto.service';
import { TipoProducto } from '../../../models/tipoproducto';

@Component({
  selector: 'app-creaeditaproducto',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    RouterLink,
    NgIf,
    CommonModule,
  ],
  templateUrl: './creaeditaproducto.component.html',
  styleUrl: './creaeditaproducto.component.css'
})
export class CreaeditaproductoComponent implements OnInit{
  form: FormGroup = new FormGroup({});
  producto: Producto = new Producto();
  listaTiposProductos: TipoProducto[] = [];
  marcas: { value: string; viewValue: string }[] = [
    { value: 'Cajas S.A.C.', viewValue: 'Cajas S.A.C.' },
    { value: 'Box Perú', viewValue: 'Box Perú' },
    { value: 'Eco Box', viewValue: 'Eco Box' },
    { value: 'Cajas Verdes', viewValue: 'Cajas Verdes' }
  ]

  constructor(
    private tS: TipoproductoService,
    private router: Router,
    private formBuilder: FormBuilder,
    private pS: ProductoService
  ){}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      c1: ['', Validators.required],
      c2: ['', Validators.required],
      c3: [
        '',
        [
          Validators.required,
          Validators.min(1),
          Validators.max(10000),
          Validators.pattern('^[0-9]*$'),
        ],
      ],
      c4: [
        '',
        [
          Validators.required,
          Validators.min(1),
          Validators.max(20000),
          Validators.pattern('^[0-9]*$'),
        ],
      ],
      c5: ['', Validators.required],
    });
    this.tS.list().subscribe((data) => {
      this.listaTiposProductos = data;
    });
  }
  aceptar():void {
    if (this.form.valid) {
      this.producto.nombreProducto = this.form.value.c1;
      this.producto.marcaProducto = this.form.value.c2;
      this.producto.precioProducto = this.form.value.c3;
      this.producto.stockProducto = this.form.value.c4;
      this.producto.tipoProducto.idTipoProducto = this.form.value.c5;
      this.pS.insert(this.producto).subscribe((data) => {
        this.pS.list().subscribe((data) => {
          this.pS.setList(data);
        });
      });
      this.router.navigate(['productos']);
    }
  }
}
