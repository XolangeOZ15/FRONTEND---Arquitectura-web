import { Routes } from '@angular/router';
import { PedidoComponent } from './components/pedido/pedido.component';
import { CreaYEditaPedidoComponent } from './components/pedido/crea-yedita-pedido/crea-yedita-pedido.component';
import { UsuarioComponent } from './components/usuario/usuario.component';
import { CreaYEditaUsuarioComponent } from './components/usuario/crea-yedita-usuario/crea-yedita-usuario.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { segGuard } from './guard/seguridad.guard';

export const routes: Routes = [
    {
        path:'',
        redirectTo:'login',pathMatch:'full'
    },
    {
        path:'login',component:LoginComponent
    },
    {
        path:'usuarios', component:UsuarioComponent,
        children:[
            {
                path:'nuevo',
                component:CreaYEditaUsuarioComponent,
            },
        ], 
    },
    {
        path:'pedidos',
        component:PedidoComponent,
        children:[
            {
                path: 'nuevo',
                component:CreaYEditaPedidoComponent,
            },
        ],
    },
    {
        path: 'homes',
        component: HomeComponent,
        canActivate:[segGuard]
    }
];
