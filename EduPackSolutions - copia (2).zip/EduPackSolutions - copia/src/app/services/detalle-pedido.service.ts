import { Injectable } from '@angular/core';
import { environment } from '../../enviroments/enviroment';
import { Subject } from 'rxjs';
import { DetallePedido } from '../models/DetallePedido';
import { HttpClient } from '@angular/common/http';
const base_url=environment.base;
@Injectable({
  providedIn: 'root'
})
export class DetallePedidoService {
  private url=`${base_url}/detallePedido`
  private listaCambio=new Subject<DetallePedido[]>()
  constructor(private http:HttpClient) { }
  listar(){
    return this.http.get<DetallePedido[]>(this.url);
  }
  registrar(detalle:DetallePedido){
    return this.http.post(this.url,detalle);
  }
  getListaCambio(){
    return this.listaCambio.asObservable();
  }
  setListaCambio(listaNueva:DetallePedido[]){
    this.listaCambio.next(listaNueva);
  }
  listId(id: number) {
    return this.http.get<DetallePedido>(`${this.url}/${id}`);
  }
  update(d:DetallePedido) { 
    return this.http.put(this.url, d);
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }
}
