import { Injectable } from '@angular/core';
import { environment } from '../../enviroments/enviroment';
import { Almacen } from '../models/Almacen';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
const base_url=environment.base;
@Injectable({
  providedIn: 'root'
})
export class AlmacenService {
  private url=`${base_url}/almacen`
  private listaCambio=new Subject<Almacen[]>()
  constructor(private http:HttpClient) { }
  listar(){
    return this.http.get<Almacen[]>(this.url);
  }
  registrar(almacen:Almacen){
    return this.http.post(this.url,almacen);
  }
  getListaCambio(){
    return this.listaCambio.asObservable();
  }
  setListaCambio(listaNueva:Almacen[]){
    this.listaCambio.next(listaNueva);
  }
  listId(id: number) {
    return this.http.get<Almacen>(`${this.url}/${id}`);
  }
  update(a:Almacen) { 
    return this.http.put(this.url, a);
  }
  eliminar(id: number) {
    return this.http.delete(`${this.url}/${id}`);
  }
}
