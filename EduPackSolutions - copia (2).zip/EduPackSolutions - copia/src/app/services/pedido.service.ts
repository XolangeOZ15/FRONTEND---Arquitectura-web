import { Injectable } from '@angular/core';
import { environment } from '../../enviroments/enviroment';
import { Subject } from 'rxjs';
import { Pedido } from '../models/Pedido';
import { HttpClient } from '@angular/common/http';

const base_url=environment.base;
@Injectable({
  providedIn: 'root'
})
export class PedidoService {
private url=`${base_url}/pedidos`
private listaCambio=new Subject<Pedido[]>();
  constructor(private http:HttpClient) { }
  listar(){
    return this.http.get<Pedido[]>(this.url);
  }
  registrar(pedido:Pedido){
    return this.http.post(this.url,pedido);
  }
  getListaCambio(){
    return this.listaCambio.asObservable();
  }
  setListaCambio(listaNueva:Pedido[]){
    this.listaCambio.next(listaNueva);
  }
}
