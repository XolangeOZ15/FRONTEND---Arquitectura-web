import { Component, OnInit, ViewChild } from '@angular/core';
import { PedidoService } from '../../../services/pedido.service';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { Pedido } from '../../../models/Pedido';

@Component({
  selector: 'app-listar-pedido',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginatorModule,
    CommonModule
  ],
  templateUrl: './listar-pedido.component.html',
  styleUrl: './listar-pedido.component.css'
})
export class ListarPedidoComponent implements OnInit {
  constructor(private pS:PedidoService){}

  displayedColumns: string[] = ['nombrepedido', 'estadopedido', 'totalpedido', 'fechapedido'];
  dataSource: MatTableDataSource<Pedido> = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator?: MatPaginator;
  
  ngOnInit(): void {
    this.pS.listar().subscribe((data)=>{
      this.dataSource= new MatTableDataSource(data);
      if(this.paginator){
        this.dataSource.paginator=this.paginator;
      }

    });
    this.pS.getListaCambio().subscribe((data)=>{
      this.dataSource= new MatTableDataSource(data);
      if(this.paginator){
        this.dataSource.paginator=this.paginator;
      }
    });
  }
}
