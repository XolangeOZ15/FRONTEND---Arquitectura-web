import { Component } from '@angular/core';
import { ActivatedRoute, RouterOutlet } from '@angular/router';
import { ListarPedidoComponent } from './listar-pedido/listar-pedido.component';

@Component({
  selector: 'app-pedido',
  standalone: true,
  imports: [
    RouterOutlet,
    ListarPedidoComponent
  ],
  templateUrl: './pedido.component.html',
  styleUrl: './pedido.component.css'
})
export class PedidoComponent {
constructor(public route:ActivatedRoute){}
}
