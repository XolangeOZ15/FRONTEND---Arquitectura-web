import { Component } from '@angular/core';

@Component({
  selector: 'app-crea-yedita-pedido',
  standalone: true,
  imports: [],
  templateUrl: './crea-yedita-pedido.component.html',
  styleUrl: './crea-yedita-pedido.component.css'
})
export class CreaYEditaPedidoComponent {

}
