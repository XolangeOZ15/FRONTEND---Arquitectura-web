import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  Form,
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Params, Router, RouterLink } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule, NgIf } from '@angular/common';
import { Usuario } from '../../../models/Usuario';
import { UsuarioService } from '../../../services/usuario.service';
import {MatDatepickerModule} from '@angular/material/datepicker';
//import { addDays, format } from 'date-fns';

@Component({
  selector: 'app-crea-yedita-usuario',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    RouterLink,
    NgIf,
    CommonModule,
    MatDatepickerModule
  ],
  templateUrl: './crea-yedita-usuario.component.html',
  styleUrl: './crea-yedita-usuario.component.css'
})
export class CreaYEditaUsuarioComponent implements OnInit {
  form: FormGroup = new FormGroup({});
  usuario: Usuario = new Usuario();
  edicion: boolean = false;
  mensaje: string = '';
  id: number = 0;
  //maxDate = addDays(new Date(), -1);
 // formattedMaxDate = format(this.maxDate, 'yyyy-MM-dd');
  constructor(
    private uS: UsuarioService,
    private router:Router,
    private formBuilder:FormBuilder,
    private route:ActivatedRoute
  ){}
  ngOnInit(): void {
    this.route.params.subscribe((data: Params) => {
      this.id = data['id'];
      this.edicion = data['id'] != null;
      this.init();
    });
    this.form = this.formBuilder.group({
      idusuario: [''],
      nombreusuario: ['', Validators.required],
      fechanacimiento: ['', Validators.required],
      emailusuario: ['', [Validators.required,Validators.email]],
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }
  aceptar(): void {
    if (this.form.valid) {
      this.usuario.id = this.form.value.idusuario;
      this.usuario.nombreUsuario = this.form.value.nombreusuario;
      this.usuario.fechaNacimiento = this.form.value.fechanacimiento;
      this.usuario.correoElectronico = this.form.value.emailusuario;
      this.usuario.username = this.form.value.username;
      this.usuario.password = this.form.value.password;
      if (this.edicion) {
        this.uS.update(this.usuario).subscribe(() => {
          this.uS.listar().subscribe((data) => {
            this.uS.setListaCambio(data);
          });
        });
      } else {
      this.uS.registrar(this.usuario).subscribe((data) => {
        this.uS.listar().subscribe((data) => {
          this.uS.setListaCambio(data);
        });
      });
    }
      this.router.navigate(['usuarios']);
    } 
  }
  init() {
    if (this.edicion) {
      this.uS.listId(this.id).subscribe((data) => {
        this.form = new FormGroup({
          id: new FormControl(data.id),
          nombreusuario: new FormControl(data.nombreUsuario),
          fechanacimiento: new FormControl(data.fechaNacimiento),
          emailusuario: new FormControl(data.correoElectronico),
          username: new FormControl(data.username),
          password: new FormControl(data.password),
        });
      });
    }
  }
}
