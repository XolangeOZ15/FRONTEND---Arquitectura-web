import { Component, OnInit, ViewChild } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Usuario } from '../../../models/Usuario';
import { MatPaginator } from '@angular/material/paginator';
import { UsuarioService } from '../../../services/usuario.service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-listar-usuario',
  standalone: true,
  imports: [MatButtonModule,MatTableModule,RouterLink,MatIconModule],
  templateUrl: './listar-usuario.component.html',
  styleUrl: './listar-usuario.component.css'
})
export class ListarUsuarioComponent implements OnInit{
  displayedColumns: string[] = 
  [ 'idusuario', 
    'nombreusuario', 
    'fechanacimiento', 
    'emailusuario',
    'username',
    'password'
  ];
  dataSource: MatTableDataSource<Usuario> = new MatTableDataSource();
  constructor(private uS:UsuarioService){}
 // @ViewChild(MatPaginator) paginator?: MatPaginator;
  
  ngOnInit(): void {
    this.uS.listar().subscribe((data)=>{
      this.dataSource= new MatTableDataSource(data);
    });
    this.uS.getListaCambio().subscribe((data)=>{
      this.dataSource= new MatTableDataSource(data);
    });
  }
}
