import { Clasificacion } from "./Clasificacion";

export class Almacen{
    idAlmacen:number=0
    cantidadCapacidad:number=0
    direccionAlmacen:string=""
    clasificacion: Clasificacion=new Clasificacion()
}
