import { Usuario } from "./Usuario"

export class Pedido{
    idPedido:number=0
    nombrePedido:string=""
    estadoPedido:string=""
    totalPedido:number=0
    fechaPedido:Date=new Date()
    usuario: Usuario=new Usuario()
}