export class Clasificacion{
    idClasificacion:number=0
    nombreClasificacion:string=""
}