export class Usuario{
    id:number=0
    nombreUsuario:string=""
    fechaNacimiento:Date=new Date()
    correoElectronico:string=""
    username:string=""
    password:string=""
    enabled:boolean | undefined
}
