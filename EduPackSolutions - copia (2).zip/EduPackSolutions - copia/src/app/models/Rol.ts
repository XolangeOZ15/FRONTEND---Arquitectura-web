import { Usuario } from "./Usuario";

export class Rol{
    id:number=0
    rol:string=""
    usuario: Usuario=new Usuario()
}
