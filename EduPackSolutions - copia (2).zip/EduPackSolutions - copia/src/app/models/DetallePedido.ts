import { Pedido } from "./Pedido"
import { Producto } from "./Producto"

export class DetallePedido{
    idDetallePedido:number=0
    cantidadPedido:number=0
    precioUnitario:number=0
    subtotalPedido:number=0
    pedido: Pedido=new Pedido()
    producto: Producto=new Producto()
}
