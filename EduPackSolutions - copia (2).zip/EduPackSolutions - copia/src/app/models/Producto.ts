import { Almacen } from "./Almacen"
import { TipoProducto } from "./TipoProducto"

export class Producto{
    idProducto:number=0
    nombreProducto:string=""
    marcaProducto:string=""
    precioProducto:number=0
    stockProducto:number=0
    almacen: Almacen=new Almacen()
    tipoProducto: TipoProducto=new TipoProducto()
}
