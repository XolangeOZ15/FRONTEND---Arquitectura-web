import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { LoginService } from './services/login.service';
import { NgIf } from '@angular/common';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    MatToolbarModule, 
    MatIconModule, 
    MatButtonModule, 
    MatMenuModule, 
    RouterLink,
    NgIf
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'EduPackSolutions';
  role: string='';
  constructor(private loginservice: LoginService){}
  cerrar(){
    sessionStorage.clear();
  }
  verificar(){
    this.role=this.loginservice.showRole();
    return this.loginservice.verificar();
  }
  isAdmin(){
    return this.role==='ADMIN';
  }
  isSupervisor(){
    return this.role==='SUPERVISOR';
  }
}
